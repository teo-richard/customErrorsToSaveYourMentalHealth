Use this to create customizable error messages in Python. This works for VS code idk if it works for other stuff.
Easy to change though damn bro

for example if you choose to put the statement:
`print("ur so gay")` in your function, and you do:
`1/0`
Your error will read `"ur so gay"`

And the function takes the params `exc_type`, `exc_value`, and `exc_traceback` so it's totally customizable.

go crazy big dog

and this is so stupid that the readme has like twice as many lines as the code fufuuuuc
